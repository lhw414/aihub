ALTER TABLE `newsletters` ADD `pdfUrl` varchar(512);--> statement-breakpoint
ALTER TABLE `newsletters` ADD `pdfThumbnailUrl` varchar(512);
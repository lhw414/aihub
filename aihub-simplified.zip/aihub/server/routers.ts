import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";

// 정적 데이터 정의
const newsletters = [
  {
    id: 1,
    title: "AI 최신 트렌드",
    description: "2024년 AI 기술의 최신 동향과 발전 방향",
    thumbnailUrl: "https://via.placeholder.com/300x200?text=AI+Trends",
    linkUrl: "https://example.com/newsletter/1",
    pdfUrl: "https://via.placeholder.com/300x200?text=PDF+1",
    pdfThumbnailUrl: "https://via.placeholder.com/300x200?text=PDF+Thumb+1",
    order: 1,
  },
  {
    id: 2,
    title: "머신러닝 기초",
    description: "머신러닝의 기본 개념과 알고리즘 이해하기",
    thumbnailUrl: "https://via.placeholder.com/300x200?text=ML+Basics",
    linkUrl: "https://example.com/newsletter/2",
    pdfUrl: "https://via.placeholder.com/300x200?text=PDF+2",
    pdfThumbnailUrl: "https://via.placeholder.com/300x200?text=PDF+Thumb+2",
    order: 2,
  },
  {
    id: 3,
    title: "딥러닝 심화",
    description: "신경망과 딥러닝 모델의 고급 기법",
    thumbnailUrl: "https://via.placeholder.com/300x200?text=Deep+Learning",
    linkUrl: "https://example.com/newsletter/3",
    pdfUrl: "https://via.placeholder.com/300x200?text=PDF+3",
    pdfThumbnailUrl: "https://via.placeholder.com/300x200?text=PDF+Thumb+3",
    order: 3,
  },
  {
    id: 4,
    title: "NLP 기술",
    description: "자연어 처리 기술의 최신 발전",
    thumbnailUrl: "https://via.placeholder.com/300x200?text=NLP",
    linkUrl: "https://example.com/newsletter/4",
    pdfUrl: "https://via.placeholder.com/300x200?text=PDF+4",
    pdfThumbnailUrl: "https://via.placeholder.com/300x200?text=PDF+Thumb+4",
    order: 4,
  },
  {
    id: 5,
    title: "컴퓨터 비전",
    description: "이미지 인식과 비전 기술의 응용",
    thumbnailUrl: "https://via.placeholder.com/300x200?text=Computer+Vision",
    linkUrl: "https://example.com/newsletter/5",
    pdfUrl: "https://via.placeholder.com/300x200?text=PDF+5",
    pdfThumbnailUrl: "https://via.placeholder.com/300x200?text=PDF+Thumb+5",
    order: 5,
  },
  {
    id: 6,
    title: "생성형 AI",
    description: "ChatGPT와 생성형 AI의 미래",
    thumbnailUrl: "https://via.placeholder.com/300x200?text=Generative+AI",
    linkUrl: "https://example.com/newsletter/6",
    pdfUrl: "https://via.placeholder.com/300x200?text=PDF+6",
    pdfThumbnailUrl: "https://via.placeholder.com/300x200?text=PDF+Thumb+6",
    order: 6,
  },
];

const aiApps = [
  {
    id: 1,
    name: "AI 텍스트 분석",
    description: "자연어 처리를 이용한 텍스트 분석 도구",
    thumbnailUrl: "https://via.placeholder.com/300x200?text=Text+Analysis",
    linkUrl: "https://example.com/app/text-analysis",
    order: 1,
  },
  {
    id: 2,
    name: "AI 이미지 처리",
    description: "이미지 인식 및 처리 기술을 활용한 도구",
    thumbnailUrl: "https://via.placeholder.com/300x200?text=Image+Processing",
    linkUrl: "https://example.com/app/image-processing",
    order: 2,
  },
  {
    id: 3,
    name: "AI 음성 인식",
    description: "음성을 텍스트로 변환하는 음성 인식 도구",
    thumbnailUrl: "https://via.placeholder.com/300x200?text=Speech+Recognition",
    linkUrl: "https://example.com/app/speech-recognition",
    order: 3,
  },
];

const quickLinkCategories = [
  { id: 1, name: "AI App", order: 1 },
  { id: 2, name: "AI 스쿨", order: 2 },
  { id: 3, name: "FAQ", order: 3 },
];

const quickLinks = [
  // AI App 카테고리
  {
    id: 1,
    categoryId: 1,
    title: "App 1",
    description: "텍스트 분석 애플리케이션",
    linkUrl: "https://example.com/app1",
    iconUrl: "https://via.placeholder.com/40x40?text=App1",
    order: 1,
  },
  {
    id: 2,
    categoryId: 1,
    title: "App 2",
    description: "이미지 처리 애플리케이션",
    linkUrl: "https://example.com/app2",
    iconUrl: "https://via.placeholder.com/40x40?text=App2",
    order: 2,
  },
  {
    id: 3,
    categoryId: 1,
    title: "App 3",
    description: "음성 인식 애플리케이션",
    linkUrl: "https://example.com/app3",
    iconUrl: "https://via.placeholder.com/40x40?text=App3",
    order: 3,
  },
  // AI 스쿨 카테고리
  {
    id: 4,
    categoryId: 2,
    title: "실라버스",
    description: "강좌 커리큘럼 확인",
    linkUrl: "https://example.com/syllabus",
    iconUrl: "https://via.placeholder.com/40x40?text=Syllabus",
    order: 1,
  },
  {
    id: 5,
    categoryId: 2,
    title: "수강신청",
    description: "강좌 등록하기",
    linkUrl: "https://example.com/enroll",
    iconUrl: "https://via.placeholder.com/40x40?text=Enroll",
    order: 2,
  },
  // FAQ 카테고리
  {
    id: 6,
    categoryId: 3,
    title: "자주 묻는 질문",
    description: "FAQ 보기",
    linkUrl: "https://example.com/faq",
    iconUrl: "https://via.placeholder.com/40x40?text=FAQ",
    order: 1,
  },
  {
    id: 7,
    categoryId: 3,
    title: "커뮤니티",
    description: "사용자 커뮤니티",
    linkUrl: "https://example.com/community",
    iconUrl: "https://via.placeholder.com/40x40?text=Community",
    order: 2,
  },
];

export const appRouter = router({
  // 뉴스레터 API
  newsletter: router({
    list: publicProcedure.query(() => newsletters),
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => newsletters.find((n) => n.id === input.id)),
  }),

  // AI App API
  aiApp: router({
    list: publicProcedure.query(() => aiApps),
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => aiApps.find((app) => app.id === input.id)),
  }),

  // 퀵링크 API
  quickLink: router({
    listWithCategories: publicProcedure.query(() => ({
      categories: quickLinkCategories,
      links: quickLinks,
    })),
  }),
});

export type AppRouter = typeof appRouter;


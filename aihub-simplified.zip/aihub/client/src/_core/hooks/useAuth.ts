// 간소화된 버전 - 인증 기능 제거
export function useAuth() {
  return {
    user: null,
    loading: false,
    error: null,
    isAuthenticated: false,
    logout: () => {},
  };
}

export function getLoginUrl() {
  return "/";
}

import NewsletterCarousel from "@/components/NewsletterCarousel";
import AiAppCarousel from "@/components/AiAppCarousel";
import QuickLinksSection from "@/components/QuickLinksSection";
import Navigation from "@/components/Navigation";
import { trpc } from "@/lib/trpc";

export default function Home() {
  // 뉴스레터 데이터 조회
  const { data: newsletters, isLoading: newslettersLoading } =
    trpc.newsletter.list.useQuery();

  // AI App 데이터 조회
  const { data: aiApps, isLoading: appsLoading } = trpc.aiApp.list.useQuery();

  // 퀵링크 데이터 조회
  const { data: quickLinksData, isLoading: quickLinksLoading } =
    trpc.quickLink.listWithCategories.useQuery();

  const isLoading = newslettersLoading || appsLoading || quickLinksLoading;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">로딩 중...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* 네비게이션 */}
      <Navigation />

      {/* 메인 콘텐츠 */}
      <main className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* 왼쪽 컬럼: 뉴스레터 + AI App */}
          <div className="lg:col-span-2 space-y-12">
            {/* AI 뉴스레터 섹션 */}
            <section>
              <div className="mb-6">
                <h2 className="text-3xl font-bold text-gray-900">
                  AI 뉴스레터
                </h2>
                <p className="text-gray-600 mt-2">
                  최신 AI 기술 뉴스와 인사이트를 만나보세요
                </p>
              </div>
              {newsletters && <NewsletterCarousel newsletters={newsletters} />}
            </section>

            {/* AI App 섹션 */}
            <section>
              <div className="mb-6">
                <h2 className="text-3xl font-bold text-gray-900">AI App</h2>
                <p className="text-gray-600 mt-2">
                  다양한 AI 애플리케이션을 체험해보세요
                </p>
              </div>
              {aiApps && <AiAppCarousel apps={aiApps} />}
            </section>
          </div>

          {/* 오른쪽 컬럼: 퀵링크 */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <div className="mb-6">
                <h2 className="text-2xl font-bold text-gray-900">
                  빠른 접근
                </h2>
              </div>
              {quickLinksData && (
                <QuickLinksSection
                  categories={quickLinksData.categories}
                  links={quickLinksData.links}
                />
              )}
            </div>
          </div>
        </div>
      </main>

      {/* 푸터 */}
      <footer className="bg-gray-900 text-white mt-20 py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <h3 className="font-bold text-lg mb-4">AI Hub</h3>
              <p className="text-gray-400">
                AI 기술의 최신 정보와 도구를 한곳에서 만나보세요
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">빠른 링크</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <a href="#" className="hover:text-white transition">
                    AI 스쿨
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition">
                    FAQ
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition">
                    커뮤니티
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">문의</h4>
              <p className="text-gray-400">
                이메일: info@aihub.com
                <br />
                전화: 02-1234-5678
              </p>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
            <p>&copy; 2024 AI Hub. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}


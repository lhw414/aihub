import { useState } from "react";

interface QuickLinkCategory {
  id: number;
  name: string;
  order: number;
}

interface QuickLink {
  id: number;
  categoryId: number;
  title: string;
  description: string;
  linkUrl: string;
  iconUrl: string;
  order: number;
}

interface QuickLinksSectionProps {
  categories: QuickLinkCategory[];
  links: QuickLink[];
}

export default function QuickLinksSection({
  categories,
  links,
}: QuickLinksSectionProps) {
  const [hoveredId, setHoveredId] = useState<number | null>(null);

  return (
    <div className="space-y-6">
      {categories.map((category) => {
        const categoryLinks = links.filter(
          (link) => link.categoryId === category.id
        );

        return (
          <div key={category.id}>
            <h3 className="text-sm font-bold text-gray-900 mb-3 uppercase tracking-wide">
              {category.name}
            </h3>
            <div className="grid grid-cols-3 gap-2">
              {categoryLinks.map((link) => (
                <div
                  key={link.id}
                  className="relative group"
                  onMouseEnter={() => setHoveredId(link.id)}
                  onMouseLeave={() => setHoveredId(null)}
                >
                  <a
                    href={link.linkUrl || "#"}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full h-12 rounded-lg bg-gradient-to-br from-blue-100 to-indigo-100 hover:from-blue-200 hover:to-indigo-200 text-gray-700 font-medium text-xs transition-all duration-200 flex items-center justify-center gap-1 border border-blue-200 hover:border-blue-400 group-hover:shadow-md"
                  >
                    {link.iconUrl && (
                      <img src={link.iconUrl} alt="" className="w-4 h-4" />
                    )}
                    <span className="line-clamp-1">{link.title}</span>
                  </a>

                  {/* Tooltip */}
                  {link.description && hoveredId === link.id && (
                    <div className="absolute bottom-full left-0 right-0 mb-2 p-2 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10 whitespace-normal">
                      {link.description}
                      <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-l-transparent border-r-transparent border-t-gray-900" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        );
      })}

      {categories.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          <p className="text-sm">퀵링크가 없습니다</p>
        </div>
      )}
    </div>
  );
}


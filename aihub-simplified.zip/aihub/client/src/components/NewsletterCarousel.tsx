import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useLocation } from "wouter";

interface Newsletter {
  id: number;
  title: string;
  description: string;
  thumbnailUrl: string;
  linkUrl: string;
  order: number;
}

interface NewsletterCarouselProps {
  newsletters: Newsletter[];
}

export default function NewsletterCarousel({
  newsletters,
}: NewsletterCarouselProps) {
  const [, navigate] = useLocation();
  const [currentPage, setCurrentPage] = useState(0);

  const itemsPerPage = 4;
  const maxPages = Math.ceil(newsletters.length / itemsPerPage) || 1;
  const startIndex = currentPage * itemsPerPage;
  const currentItems = newsletters.slice(startIndex, startIndex + itemsPerPage);

  const handlePrev = () => {
    setCurrentPage((prev) => (prev > 0 ? prev - 1 : maxPages - 1));
  };

  const handleNext = () => {
    setCurrentPage((prev) => (prev < maxPages - 1 ? prev + 1 : 0));
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        {currentItems.map((item) => (
          <div
            key={item.id}
            onClick={() => navigate(`/newsletter/${item.id}`)}
            className="group cursor-pointer rounded-lg overflow-hidden bg-gray-100 hover:shadow-lg transition-all duration-300 transform hover:scale-105 block"
          >
            {item.thumbnailUrl && (
              <div className="relative h-32 overflow-hidden">
                <img
                  src={item.thumbnailUrl}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
              </div>
            )}
            <div className="p-4">
              <h3 className="font-semibold text-gray-900 line-clamp-2 group-hover:text-blue-600 transition">
                {item.title}
              </h3>
              {item.description && (
                <p className="text-sm text-gray-600 line-clamp-2 mt-2">
                  {item.description}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Navigation Controls */}
      {maxPages > 1 && (
        <div className="flex items-center justify-between mt-6">
          <button
            onClick={handlePrev}
            className="p-2 rounded-full bg-blue-600 text-white hover:bg-blue-700 transition-colors"
            aria-label="Previous"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <div className="flex gap-2">
            {Array.from({ length: maxPages }).map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentPage(idx)}
                className={`w-2 h-2 rounded-full transition-all ${
                  idx === currentPage ? "bg-blue-600 w-8" : "bg-gray-300"
                }`}
                aria-label={`Go to page ${idx + 1}`}
              />
            ))}
          </div>

          <button
            onClick={handleNext}
            className="p-2 rounded-full bg-blue-600 text-white hover:bg-blue-700 transition-colors"
            aria-label="Next"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      )}
    </div>
  );
}

